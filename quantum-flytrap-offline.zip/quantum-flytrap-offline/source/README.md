Rebuild with npm ci && npm run build from this directory. The output will be dist/index.html. See ../README.md for usage, validation, attribution, and limitations.
